#include "serial_com.h"

Serial pc(USBTX, USBRX);
SDFileSystem sd(p5, p6, p7, p8, "sd"); // the pinout on the mbed Cool Components workshop board


extern volatile char data_out;
extern volatile char data_in;
extern volatile bool data_in_flag;

char highscores[5][7];
//char highscoreNames[5][4];

void getHighScoresFromSD(){
    //pc.printf("Reading High Scores\n");
    pc.putc('A');
    //pc.putc('\n');
    FILE *fp = fopen("/sd/highScores.txt", "r");
    if(fp == NULL) {
        //pc.printf("Could not open file for write\n");
        error("Could not open file for write\n");
    }    
    //pc.printf("File opened\n");
    //char buf[8];
    char in;
    int highScoreNum =0;
    for(highScoreNum = 0; highScoreNum<5; highScoreNum++){
        //start character
        pc.putc(0x0A);
        //7 bytes plus CR
        for (int i=0; i<8; i++) {
            in = fgetc(fp);
            highscores[highScoreNum][i] = in;
            pc.putc(in);
            //pc.printf("buf: %c\n", in);
        }
        //take care of LF
        fgetc(fp);
    }
    fclose(fp);
    //pc.putc(0x);
    //pc.printf("File closed");
}

void writeNewHighScoresToSD(){
    FILE *fp = fopen("/sd/highScores.txt", "w");
    if(fp == NULL) {
        //pc.printf("Could not open file for write\n");
        error("Could not open file for write\n");
    }
    pc.putc(0x77);
//    while(pc.getc() != 0x10){};
    int highScoreReplaceNum =pc.getc();
    for(int highScoreNum = 0; highScoreNum<5; highScoreNum++){
        for (int i=0; i<7; i++) {
            if(highScoreNum < highScoreReplaceNum){
                fputc(highscores[highScoreNum][i],fp);    
            }else if(highScoreNum == highScoreReplaceNum){
                fputc(pc.getc(),fp);    
            }else if(highScoreNum > highScoreReplaceNum){
                fputc(highscores[highScoreNum-1][i],fp);
            }
            
        }
        fputc(0x0D,fp);
        fputc(0x0A,fp);
    }
    fclose(fp);
    pc.putc(0x77);
}

void serial_thread(){
        
    while(1){
        if(pc.readable()){
            data_in = pc.getc();
            data_in_flag = true;
            if(data_in & REQUEST_HIGH_SCORES){
                pc.putc(0x55);
                getHighScoresFromSD();
                data_in &= ~REQUEST_HIGH_SCORES;
            }
            if(data_in & NEW_HIGH_SCORE){
                writeNewHighScoresToSD();
                data_in &= ~NEW_HIGH_SCORE;
            }
            
            //data_out += 0b10000000;
        }
        //send through serial port
        pc.putc(data_out);
        //printf("Data: %d", data);
        Thread::wait(100);
    }
}