#pragma once

#include "SDFileSystem.h"
#include "rtos.h"

#define REQUEST_HIGH_SCORES 0b10000000
#define NEW_HIGH_SCORE      0b00100000

void serial_thread();