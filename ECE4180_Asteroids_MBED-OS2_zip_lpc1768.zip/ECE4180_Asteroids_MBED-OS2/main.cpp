#include "mbed.h"
#include "SDFileSystem.h"
#include "MMA8452.h"
#include "wave_player.h"
#include "SongPlayer.h"
#include "rtos.h"
#include "serial_com.h"


Thread thread_serial;
Thread thread_speaker;

/*float note[18]= {1568.0,1396.9,1244.5,1244.5,1396.9,1568.0,1568.0,1568.0,1396.9,
                 1244.5,1396.9,1568.0,1396.9,1244.5,1174.7,1244.5,1244.5, 0.0
                };
float duration[18]= {0.48,0.24,0.72,0.48,0.24,0.48,0.24,0.24,0.24,
                     0.24,0.24,0.24,0.24,0.48,0.24,0.48,0.48, 0.0
                    };
*/  
float shotFiredNote[4] = {1568.0,1396.9,1244.5, 0.0};
float shotFiredDuration[4] = {0.05,0.025,0.05, 0.0};

float collisionNote[4] = {568.0,396.9,244.5, 0.0};
float collisionDuration[4] = {0.05,0.025,0.05, 0.0};

float asteroidNote[4] = {1244.5,1396.9, 1568.0,0.0};
float asteroidDuration[4] = {0.025,0.03,0.05, 0.0};

float note[6]= {1568.0,1396.9,1244.5,1244.5,1396.9, 0.0};
float duration[6]= {0.048,0.024,0.072,0.048,0.024, 0.0};

volatile char data_out;
volatile char data_in;
volatile bool data_in_flag;
 
//Serial pc(USBTX, USBRX);
MMA8452 acc(p28, p27, 100000);        // Accelerometer (sda, sdc, rate)
DigitalIn button1(p22);                 // Pushbuttons (pin)
DigitalIn button2(p23);
DigitalIn button3(p24);
//SDFileSystem sd(p5, p6, p7, p8, "sd"); // the pinout on the mbed Cool Components workshop board

DigitalOut led1(LED1);
DigitalOut led2(LED2);
SongPlayer mySpeaker(p21);

#define UP      0b00000001
#define DOWN    0b00000010
#define LEFT    0b00000100
#define RIGHT   0b00001000
#define THRUST  0b00010000
#define SHIELD  0b00100000
#define FIRE    0b01000000

#define SHOT_FIRED      0b00000001
#define ASTEROID_SHOT   0b00000010
#define COLLISION       0b00000100
#define GAME_OVER           0b00001000


struct GameInputs {
    int b1, b2, b3;     // Button presses
    double ax, ay, az;  // Accelerometer readings
};

GameInputs read_inputs() 
{
    GameInputs in;
    in.b1 = button1;
    in.b2 = button2;
    in.b3 = button3;
    acc.readXYZGravity(&(in.ax),&(in.ay),&(in.az));
    return in;
}
   
int create_data_packet(GameInputs in){
    int data =0;
        
    if(in.ax < -0.4){
        data +=  UP;//up
    }else if(in.ax >0.4){
        data += DOWN;//down
    }
    if(in.ay < -0.4){
       data += RIGHT; //right
    }else if(in.ay > 0.4){
        data += LEFT;//left   
    }
    if(!in.b1){
        data += THRUST;   
    }
    if(!in.b2){
        data += SHIELD;    
    }
    if(!in.b3){
        data += FIRE;    
    }
    return data;
}


void speaker_thread(){
    while(1){
        
        while(data_in_flag){
            led1=1;
            //read data_in to get which event happened
            switch (data_in){
                case SHOT_FIRED:
                        //SD Card
                    led2=1;
                    
                    mySpeaker.PlaySong(shotFiredNote,shotFiredDuration);
                    data_in &= ~SHOT_FIRED;
                    led2=0;
                    break;
                case ASTEROID_SHOT:
                    //mySpeaker.PlaySong(note,duration);
                    
                    mySpeaker.PlaySong(asteroidNote,asteroidDuration);
                    data_in &= ~ASTEROID_SHOT;
                    break;
                case COLLISION:
                    //mySpeaker.PlaySong(note,duration);
                    
                    mySpeaker.PlaySong(collisionNote,collisionDuration);
                    data_in &= ~COLLISION;
                    break;
                
            }
            if(!data_in){
                data_in_flag = false;    
            }
        }
        
        Thread::wait(100);
        led1=0;
    }
}






int main() {
    //pc.printf("Hello World1\n");
    //Initialize pushbuttons
    button1.mode(PullUp); 
    button2.mode(PullUp);
    button3.mode(PullUp); 
    
    thread_speaker.start(speaker_thread);
    thread_serial.start(serial_thread);
 
    
    //pc.printf("Hello World\n");
    GameInputs in;

    //main thread will be reading inputs and creating data packet
    while(1) {
        in = read_inputs();
        //pc.printf("ax: %f ay: %f az: %f\n", in.ax, in.ay, in.az);
        data_out = create_data_packet(in);

        Thread::wait(100);
    }
}
