/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
    main function for a 3D pacman game in openGL
*/

#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <vector>
#include "ECE_Bitmap.h"
//#include <string>
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>
#include <mutex>
#include "ECE_Ghost.h"
#include "ECE_Pacman.h"
#include "Maze.h"


using namespace std;
//Establishing globals
mutex leaveGateMutex;
mutex mazeMutex;
mutex powerupMutex;
ECE_Pacman pacman;
ECE_Ghost ghosts[4];
vector<thread> powerupThread;
bool poweredup;
bool keypressed;
int numHoneydews = 0;
char maze[MAZE_HEIGHT][MAZE_WIDTH];
int map[MAZE_HEIGHT][MAZE_WIDTH];

// camera in circle in (ew) polar bc it depends on angle
int angle = 135;
float r = sqrt(95 * 95 + 110 * 110);
float x = r * sinf(angle * M_PI / 180);
float y = r * cosf(angle * M_PI / 180);


// Keyboard function called with keyboard presses, r changed camera angle and esc exits
void Keyboard(unsigned char key, int x, int y) {
    if (!keypressed && key) {
        keypressed = true;
        for (int i = 0; i < 4; i++) {
            ghosts[i].startThread();
        }
    }
    switch (key) {
    case 'r':
        angle -= 5;
        break;
    case 27:
        exit(0);
    }
    glutPostRedisplay();
}

void SpecialInput(int key, int x, int y) {
    if (!keypressed && key) {
        keypressed = true;
        for (int i = 0; i < 4; i++) {
            ghosts[i].startThread();
        }
    }

    switch (key) {
    case GLUT_KEY_DOWN:
        pacman.setDesired(DOWN_DIR);
        //pacman starts moving down
        break;
    case GLUT_KEY_UP:
        //pacman starts moving up
        pacman.setDesired(UP_DIR);
        break;
    case GLUT_KEY_LEFT:
        pacman.setDesired(LEFT_DIR);
        //pacman starts moving left
        break;
    case GLUT_KEY_RIGHT:
        pacman.setDesired(RIGHT_DIR);
        //pacman starts moving right
        break;
    }
    glutPostRedisplay();
}

//initializes graphics, specular lighting
void init(void)
{
    poweredup = false;
    Maze::init_Maze();

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Specular Lighting
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    
}

//reshapes the screen
void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(80.0, (GLfloat)w / (GLfloat)h, 100.0, 550.0);
    glMatrixMode(GL_MODELVIEW);

}

//displays, draws maze and sets up camera
void display(void) {
    // Clear frame buffer and depth buffer
    pacman.move();
    //cout << pacman.lives << endl;
    if (pacman.lives <= 0) {
        pacman.exitGame();
    }
    //cout<< pacman.getX() << " " << pacman.getY() << endl;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



    Maze::drawMaze();

    
//marking origin- exact center of maze
    /*
glColor3f(1.0, 1.0, 1.0);
glPushMatrix();
glEnable(GL_TEXTURE_2D);
glBindTexture(GL_TEXTURE_2D, texture[0]);
glutSolidSphere(3.0, 20, 20);
glDisable(GL_TEXTURE_2D);
glPopMatrix();

*/
    // Set up viewing transformation
    glLoadIdentity();

    // camera location - convert from polar to rectangular
    x = r * sinf(angle * M_PI / 180);
    y = r * cosf(angle * M_PI / 180);

    // Camera
    gluLookAt(x, y, 125, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
    glutSwapBuffers();
    glutPostRedisplay();
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
}


int main(int argc, char** argv)
{
    keypressed = false;
    // GLUT Window Initialization:
    glutInit(&argc, argv);
    glutInitWindowSize(800, 800);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Pacman");
    // Initialize OpenGL graphics state
    init();
    // Register callbacks:
    glutDisplayFunc(display);
    //called when someone resizes the window
    glutReshapeFunc(reshape);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialInput);

    //glutPostRedisplay();
    glutMainLoop();
    for (thread& th : powerupThread) {
        th.join();
    }
    for (ECE_Ghost& g : ghosts) {
        g.getThread().join();
    }

    return 0;
}