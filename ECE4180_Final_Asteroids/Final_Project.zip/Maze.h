/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 10/29/2020
Description:
	Maze header file that holds the maze as an array of chars, drawMaze to draw the maze, and helper functions for drawMaze
*/
#pragma once
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>

#define MAZE_WIDTH 19
#define MAZE_HEIGHT 22

#define VERT 1
#define HORIZ 0

const char original_maze[22][19] =
{ {'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W'},
{'W','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','W'},
{'W','H','W','W','W','W','W','W','H','W','H','W','W','W','W','W','W','H','W'},
{'W','H','H','H','H','W','H','H','H','W','H','H','H','W','H','H','H','H','W'},
{'W','W','H','W','H','W','H','W','W','W','W','W','H','W','H','W','H','W','W'},
{'W','P','H','W','H','H','H','H','H','M','H','H','H','H','H','W','H','P','W'},
{'W','H','W','W','H','W','W','W','H','W','H','W','W','W','H','W','W','H','W'},
{'W','H','H','H','H','H','H','H','H','W','H','H','H','H','H','H','H','H','W'},
{'W','W','W','W','H','W','E','W','W','W','W','W','E','W','H','W','W','W','W'},
{'E','E','E','W','H','W','E','E','E','E','E','E','E','W','H','W','E','E','E'},
{'W','W','W','W','H','W','E','W','W','W','W','W','E','W','H','W','W','W','W'},
{'E','E','E','E','H','E','E','W','4','2','3','W','E','E','H','E','E','E','E'},
{'W','W','W','W','H','W','E','W','W','1','W','W','E','W','H','W','W','W','W'},
{'E','E','E','W','H','W','E','E','E','E','E','E','E','W','H','W','E','E','E'},
{'W','W','W','W','H','W','W','W','E','W','E','W','W','W','H','W','W','W','W'},
{'W','H','H','H','H','W','H','H','H','W','H','H','H','W','H','H','H','H','W'},
{'W','H','W','W','H','W','H','W','W','W','W','W','H','W','H','W','W','H','W'},
{'W','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','H','W'},
{'W','H','W','W','H','W','W','W','H','W','H','W','W','W','H','W','W','H','W'},
{'W','P','W','W','H','W','W','W','H','W','H','W','W','W','H','W','W','P','W'},
{'W','H','H','H','H','H','H','H','H','W','H','H','H','H','H','H','H','H','W'},
{'W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W','W'} };

//method drawMaze draws the maze using additional helper functions
class Maze
{

public:
	//draws maze
	static void drawMaze();
	static void init_Maze();
private:
	//draws honeydew as white ball
	static void drawHoneydew();
	//draws powerup as gold disk
	static void drawPowerUp();
	//draws wall as blue cylinder with height from input parameter
	static void drawWall(int height);
	//takes in a spot in the maze as row and col, and a direction (vertical = 0, horizontal = 1), then returns the length of the wall in that direction from the given point, the height the wall cylinder needs to be
	static int getWallHeight(int row, int col, int direction);

};

