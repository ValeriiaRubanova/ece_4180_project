/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
	ECE_Pacman ghost file, does ghost stuff
*/
#pragma once
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <string>
#include <iostream>
#include <iomanip>
#include <queue>
#include <math.h>
#include <ctime>
#include <thread>
#include <mutex>
#include "ECE_Pacman.h"

extern char maze[MAZE_HEIGHT][MAZE_WIDTH];
extern bool poweredup;
extern std::mutex leaveGateMutex;
//Ghost that is a color, can be drawn as a cylinder with a sphere
class ECE_Ghost {
	static int numGhosts;
private:
	float red;
	float green;
	float blue;
	int xpos;
	int ypos;
	int startx;
	int starty;
	char map_char;
	std::thread th;
	
public:
	bool reset;
	bool inGate;
	bool honeydew;
	bool powerup;
	
	//default constructor
	ECE_Ghost();
	//draws ghost as a cylinder with a sphere, in the color of that ghost
	void drawGhost();

	//getters and setters
	int getX() { return xpos; };
	int getY() { return ypos; };
	void setX(int x);
	void setY(int y);
	std::thread& getThread();
	char getMapChar();

	//begin ghost actions
	void startThread();

	//move a ghost to a new coordinate
	bool move(int, int);

	//resets the ghost to initial conditions
	void resetGhost();

};