/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
	node cpp file for A* algorithm nodes
*/

#include "Node.h"
#include "Maze.h"

using namespace std;
//-----------------------------------------------------
// A* Pathfinding Algorithm
//-----------------------------------------------------

Node::Node(int x, int y)
{
	this->x = x;
	this->y = y;
	this->f = 0;
	this->g = 0;
	this->h = 0;
}

Node::Node() {
	this->x = 0;
	this->y = 0;
	this->f = 0;
	this->g = 0;
	this->h = 0;
}

bool isValid(int x, int y)
{
	return (original_maze[x][y] != 'W');
}

bool isDestination(int x, int y, Node end)
{
	return (x == end.x && y == end.y);
}

double calcHVal(int x, int y, Node end)
{
	return (double)(abs(x - end.x) + abs(y - end.y));
}

void removeElement(Node element, vector<Node> &nodes)
{
	for (int i = 0; i <nodes.size(); ++i)
	{
		//cout << vec.at(i).x << " " << element.x << " " << vec.at(i).y << " " << element.y<<endl;
		if (nodes.at(i).x == element.x && nodes.at(i).y == element.y) {
			//cout << "removing node" << endl;
			nodes.erase(nodes.begin() + i);
		}
	}
}

bool hasElement(Node element, const vector<Node>& nodes)
{
	for (int i = 0; i<nodes.size(); i++){
		if (nodes.at(i).x == element.x && nodes.at(i).y == element.y)
			return true;
	}
	return false;
}

vector<Node> Node::getNeighbors(const vector < vector <Node> > &grid)
{
	int x = this->x;
	int y = this->y;

	vector<Node> neighbors;

	if (x < 21 && original_maze[x + 1][y] != 'W') {
		neighbors.push_back(grid.at(x + 1).at(y));
	}
	if (x > 0 && original_maze[x - 1][y] != 'W') {
		neighbors.push_back(grid.at(x - 1).at(y));
	}
	if (y < 18 && original_maze[x][y + 1] != 'W') {
		neighbors.push_back(grid.at(x).at(y + 1));
	}
	if (y > 0 && original_maze[x][y - 1] != 'W') {
		neighbors.push_back(grid.at(x).at(y - 1));
	}
	//for (Node n : neighbors) {
//		n.parentX = x;
//		n.parentY = y;
	//}
	return neighbors;
}