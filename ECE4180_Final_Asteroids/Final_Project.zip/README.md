##READ ME

3D pacman game
written on Windows OS with OpenGL and GLUT libraries, and threading.


compile with
main.cpp ECE_Pacman.cpp Maze.cpp ECE_Ghost.cpp -lpthread -lgl -lglut

LINK TO VIDEO:
https://drive.google.com/file/d/1zYna3V8HNt9Bn_xiHxElWbCJe-je56Ae/view?usp=sharing