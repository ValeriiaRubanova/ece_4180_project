/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 11/28/2020
Description:
    Maze cpp file that holds the maze as an array of chars, drawMaze to draw the maze, and helper functions for drawMaze
*/
#pragma once
//#include "Maze.h"
#include "ECE_Pacman.h"
#include "ECE_Ghost.h"
#include <iostream>
extern int numHoneydews;
extern ECE_Pacman pacman;
extern ECE_Ghost ghosts[4];
extern char maze[MAZE_HEIGHT][MAZE_WIDTH];
extern const char original_maze[MAZE_HEIGHT][MAZE_WIDTH];

//draws honeydew white ball
void Maze::drawHoneydew() {
    glColor3f(1.0, 1.0, 1.0);
    glPushMatrix();
    glutSolidSphere(1.5, 20, 20);
    glPopMatrix();
}

//draws powerup as a gold disk
void Maze::drawPowerUp() {
    glColor3f(1.0, 0.84375, 0.0);
    glPushMatrix();
    GLUquadricObj* q;
    q = gluNewQuadric();
    gluDisk(q, 0, 2, 30, 30);
    glPopMatrix();
}

//draws wall as a blue cylinder with height @param Height
void Maze::drawWall(int height) {
    height = (height - 1) * 8;
    glColor3f(0.0, 0.0, 1.0);
    glPushMatrix();
    GLUquadricObj* q;
    q = gluNewQuadric();
    gluCylinder(q, 1.5, 1.5, GLdouble(height), 20, 20);
    glPopMatrix();

}

//gets the length of the wall from the current spot (row, col) in the direction direction (vertical = 0, horizontal = 1). returns the height the cylinder for the wall needs to be
int Maze::getWallHeight(int row, int col, int direction) {
    if (row >= 0 && row < 22 && col >= 0 && col < 19 && (maze[row][col] == 'W' || maze[row][col] == 'V')) {
        switch (direction) {
            //horizontal
        case 0:
            return 1 + getWallHeight(row, col + 1, direction);
            break;
            //vertical
        case 1:
            //marks it as already done horizontal, only needs to check vertical
            maze[row][col] = 'V';
            return 1 + getWallHeight(row + 1, col, direction);
        }

    }
    else {
        return 0;
    }

}
//initializes maze as the initial maze
void Maze::init_Maze() {
    for (int i = 0; i < 22; ++i) {
        for (int j = 0; j < 19; j++) {
            maze[i][j] = original_maze[i][j];
            if (original_maze[i][j] == 'H') {
                numHoneydews++;
            }
            
        }
    }
}
//draws the maze with all of the walls, honeydews, ghosts, powerups, and pacman
void Maze::drawMaze() {
    int numGhosts = 0;
    int height;

    glPushMatrix();
    //19 rows along the x axis
    glTranslatef(-72.0, 0.0, 0.0);
    for (int row = 0; row < 19; ++row)
    {
        glPushMatrix();
        //22 rows along the y axis
        glTranslatef(0.0, -84.5, 0.0);
        for (int col = 0; col < 22; ++col)
        {
            switch (maze[col][row]) {
            case 'W':
                //draw wall vertically
                height = getWallHeight(col, row, VERT);
                glPushMatrix();
                glRotatef(-90, 1.0, 0.0, 0);
                drawWall(height);
                glPopMatrix();

                //no break- flows through and also draws horizontal wall!
            //if vertical wall has already been drawn in this spot, only draw horizontal wall
            case 'V':
                height = getWallHeight(col, row, HORIZ);
                glPushMatrix();
                glRotatef(90, 0.0, 1.0, 0);
                drawWall(height);
                glPopMatrix();
                break;
            case 'P':
                drawPowerUp();
                break;
            case 'H':
                drawHoneydew();
                break;
            //ghosts
            case '1':
                ghosts[0].drawGhost();
                break;
            case '2':
                ghosts[1].drawGhost();
                break;
            case '3':
                ghosts[2].drawGhost();
                break;
            case '4':
                ghosts[3].drawGhost();
                break;
            //pacman
            case 'M':
                pacman.drawPacman();
                break;
            }

            glTranslatef(0.0, 8.0, 0.0);
        }

        glPopMatrix();
        glTranslatef(8.0, 0.0, 0.0);
    }

    glPopMatrix();

    //resets walls
    for (int i = 0; i < 22; ++i) {
        for (int j = 0; j < 19; j++) {
            if (maze[i][j] == 'V') {
                maze[i][j] = 'W';
            }
        }
    }
}