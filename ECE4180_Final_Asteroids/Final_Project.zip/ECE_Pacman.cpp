/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
    ECE_Pacman cpp file, does pacman stuff
*/
#pragma once
#include "ECE_Pacman.h"

using namespace std;

extern ECE_Ghost ghosts[4];
extern mutex powerupMutex;
extern bool poweredup;
extern vector<thread> powerupThread;
extern bool poweredup;

//default constructor
ECE_Pacman::ECE_Pacman() {
    xpos = 5;
    ypos = 9;
    lives = 3;
    curr_dir = NO_DIR;
    desired_dir = NO_DIR;
}
//function that the powerup threads use, enters powerup phase for 5 seconds
void powerupTimer() {
    //cout << "entered powerup timer function" << endl;
    powerupMutex.lock();
    poweredup = true;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    poweredup = false;
    powerupMutex.unlock();
    //cout << "powerup timer done" << endl;
}
//setter for direction
void ECE_Pacman::setDesired(enDIRECTIONS dir) {
    desired_dir = dir;
}
//draws pacman as a yellow sphere
void ECE_Pacman::drawPacman() {
    glColor3f(1.0, 1.0, 0.0);
    glPushMatrix();
    //glBindTexture(GL_TEXTURE_2D, texture[1]);
    glutSolidSphere(3.0, 20, 20);
    glPopMatrix();
}
//moves pacman based on user input
void ECE_Pacman::move() {
    if (desired_dir == NO_DIR) {
        return;
    }
    else if (desired_dir == UP_DIR) {
        if (isMoveAllowed(xpos + 1, ypos)) {
            curr_dir = desired_dir;
            maze[xpos][ypos] = 'E';
            moveToNewLoc(xpos + 1, ypos);
            return;
        }
    }
    else if (desired_dir == DOWN_DIR) {
        if (isMoveAllowed(xpos - 1, ypos)) {
            curr_dir = desired_dir;
            maze[xpos][ypos] = 'E';
            moveToNewLoc(xpos - 1, ypos);
            return;
        }
    }
    else if (desired_dir == LEFT_DIR) {
        if (isMoveAllowed(xpos, ypos-1)) {
            curr_dir = desired_dir;
            maze[xpos][ypos] = 'E';
            moveToNewLoc(xpos, ypos-1);
            return;
        }
    }
    else if (desired_dir == RIGHT_DIR) {
        if (isMoveAllowed(xpos, ypos+1)) {
            curr_dir = desired_dir;
            maze[xpos][ypos] = 'E';
            moveToNewLoc(xpos, ypos+1);
            return;
        }
    }
    desired_dir = curr_dir;

}
//moves pacman object to new location in map
void ECE_Pacman::moveToNewLoc(int x, int y) {
    switch (maze[x][y]) {
    case 'H':
        numHoneydews--;
        break;
    case 'P':
        powerupThread.push_back(std::thread(powerupTimer));
        //cout << powerupThread.size() << " powerup threads" << endl;
        break;
    }
    //if ghost
    if (atoi(&maze[x][y]) > 0) {
        if (!poweredup) {
            pacmandies();
        }
        else {
            ghosts[atoi(&maze[x][y]) - 1].reset = true;
        }
        return;
    }
    
    if (numHoneydews == 0) {
        std::cout << "you win!" << std::endl;
        lives = 0;
        for (int i = 0; i < 4;i++) {
            ghosts[i].getThread().join();
        }
        for (int i = 0; i < powerupThread.size(); i++) {
            if (powerupThread.at(i).joinable())
                powerupThread.at(i).join();
        }
        glutPostRedisplay();
        exit(0);
    }
    if (x == 11 && y == -1) {
        maze[x][18] = 'M';
    }
    else if (x == 11 && y == 19) {
        maze[x][0] = 'M';
    }
    else {
        maze[x][y] = 'M';
    }
    setLocation(x, y);
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
}

void ECE_Pacman::setLocation(int x, int y) {
    if (x == 11 && y == -1) {
        xpos = x;
        ypos = 18;
    }
    else if (x == 11 && y == 19) {
        xpos = x;
        ypos = 0;
    }
    else {
        xpos = x;
        ypos = y;
    }
}
bool ECE_Pacman::isMoveAllowed(int x, int y) {
    if ((x == 11 && y == -1) || (x == 11 && y == 19)) {
        return true;
    }
    if (maze[x][y] != 'W' && !((x == 11 && (y == 8 || y == 9 || y == 10)) || (x == 12 && y == 9))) {
        return true;
    }
    return false;
}

//pacman dies
void ECE_Pacman::pacmandies() {
    lives--;
    //cout << "lives --" << endl;

        for (int i = 0; i < 4;i++) {
            ghosts[i].reset = true;
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            //cout << "reset ghost " << i << endl;
        }
        maze[xpos][ypos] = 'E';
        //cout << "resetting loc" << endl;
        moveToNewLoc(5, 9);
        maze[5][9] = 'M';
        desired_dir = NO_DIR;
        curr_dir = NO_DIR;
       // cout << xpos << " " << ypos << endl;
        glutPostRedisplay();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
}

//exits game, closes all threads
void ECE_Pacman::exitGame() {
    std::cout << "you lose!" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    for (int i = 0; i < 4;i++) {
        ghosts[i].getThread().join();
        //cout << "joined ghost thread " << i << endl;
    }

    //cout << "size: " << powerupThread.size() << endl;
    for (int i = 0; i < powerupThread.size(); i++) {
        //cout << "thread " << i << endl;
        if (powerupThread.at(i).joinable()) {
            // cout << "joinable" << endl;
            powerupThread.at(i).join();
            //cout << "joined powerup thread " << i << endl;
        }
    }

    //glutPostRedisplay();
    exit(0);
}