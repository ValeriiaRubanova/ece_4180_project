/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
	ECE_Pacman header file, does pacman stuff
*/
#pragma once
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include "Maze.h";
#include "ECE_Ghost.h"
#include "enDIRECTIONS.h"

enum enDIRECTIONS { NO_DIR, UP_DIR, DOWN_DIR, LEFT_DIR, RIGHT_DIR };

extern char maze[MAZE_HEIGHT][MAZE_WIDTH];
extern int numHoneydews;
//has method to draw pacman
class ECE_Pacman {
public:
	//draws pacman as a yellow sphere
	ECE_Pacman();
	void setLocation(int x, int y);
	void setDesired(enDIRECTIONS dir);

	int getX(){ return xpos; };
	int getY() { return ypos; };

	void drawPacman();
	void move();
	void pacmandies();
	void exitGame();
	int lives;
private:
	int xpos;
	int ypos;
	
	enDIRECTIONS curr_dir;
	enDIRECTIONS desired_dir;

	bool isMoveAllowed(int x, int y);
	void moveToNewLoc(int x, int y);
};