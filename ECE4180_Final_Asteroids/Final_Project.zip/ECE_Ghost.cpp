/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
	ECE_Ghost cpp file, does ghost stuff
*/
#pragma once
#include "ECE_Ghost.h"
#include "Node.h"

using namespace std;

int ECE_Ghost::numGhosts = 0;
extern ECE_Pacman pacman;
extern mutex mazeMutex;



//A* Shortest path algorithm
//Reworked code from online tutorial in another programming language
vector<Node> shortestPath(Node start, Node end)
{
	//cout << "Entered aStar" << endl;
	vector< vector < Node > > grid;
	grid.resize(22);
	for (int row = 0; row < 22; ++row)
	{
		grid.at(row).resize(19);
		for (int col = 0; col < 19; ++col)
		{
			grid.at(row).at(col).x = row;
			grid.at(row).at(col).y = col;
			grid.at(row).at(col).f = 0;
			grid.at(row).at(col).g = 0;
			grid.at(row).at(col).h = 0;
		}
	}
	//cout << "created empty grid" << endl;
	vector<Node> openSet;
	vector<Node> closedSet;

	openSet.push_back(grid.at(start.x).at(start.y));

	while (openSet.size() > 0)
	{
		int lowest = 0;
		for (int i = 0; i < openSet.size(); ++i)
		{
			if (openSet[i].f < openSet[lowest].f)
				lowest = i;
		}

		Node current = openSet[lowest];
		//cout << "current node: " << current.x << " " << current.y << endl;
		if (isDestination(current.x, current.y, end))
		{
			vector<Node> path;
			Node node1 = current;
			path.push_back(node1);
			//cout << "pushed back node 1" << endl;
			while (node1.parentX)
			{
				//cout << "entered parent while loop" << endl;
				int x = node1.parentX;
				int y = node1.parentY;

				node1 = grid.at(x).at(y);
				path.push_back(node1);
			}
			//cout << "returning a path" << endl;
			return path;
		}
		//cout << "current: " << current.x << " " << current.y << endl;
		//cout << "Size of open nodes vector: " << openSet.size() << endl;
		//for (Node n : openSet) {
		//	cout << "node: " << n.x << " " << n.y << endl;
		//}
		


		vector<Node> neighbors = current.getNeighbors(grid);
		//for (Node n : neighbors) {
		//	cout << "node: " << n.x << " " << n.y << endl;
		//}
		for (Node neighbor : neighbors)
		{
			neighbor.parentX = current.x;
			neighbor.parentY = current.y;
			//Node neighbor = neighbors.at(i);

			if (!hasElement(neighbor, closedSet) && original_maze[neighbor.x][neighbor.y] != 'W')
			{
				double tempG = current.g + 1;

				if (hasElement(neighbor, openSet))
				{
					/*
					int index;
					for (int i = 0; i < openSet.size(); i++) {
						if (openSet.at(i).x == neighbor.x && openSet.at(i).y == neighbor.y) {
							index = i;
						}
					}
					*/
					if (tempG < neighbor.g || neighbor.g == 0)
					{
						neighbor.g = tempG;
						
					}
					else {
						continue;
					}
				}
				else {
					neighbor.g = tempG;
					
				}

				neighbor.h = calcHVal(neighbor.x, neighbor.y, end);
				neighbor.f = neighbor.g + neighbor.h;
				grid.at(neighbor.x).at(neighbor.y) = neighbor;
				openSet.push_back(neighbor);
			}

		}
		removeElement(current, openSet);
		//cout << "Size of open nodes vector: " << openSet.size() << endl;
		//for (Node n : openSet) {
		//	cout << "node: " << n.x << " " << n.y << endl;
		//}
		closedSet.push_back(current);

	}
	//cout << "empty path" << endl;
	vector<Node> empty;
	return empty;
}

//function that the thread preforms, does ghost stuff
void ghostActions(ECE_Ghost* ghost) {
	//cout << "thread started" << endl;
	//std::this_thread::sleep_for(std::chrono::seconds(2));
	maze[ghost->getX()][ghost->getY()] = ghost->getMapChar();
	glutPostRedisplay();
	int newx;
	int newy;
	while (true) {
		std::this_thread::sleep_for(std::chrono::milliseconds(300));
		if (pacman.lives <= 0) {
			break;
		}
		if (ghost->reset) {
			ghost->resetGhost();
		}
		if (ghost->inGate) {
			//cout << "in gate" << endl;
			while (!leaveGateMutex.try_lock())
			{
				//cout << "mutex was locked, sleeping" << endl;
				//if someone else is leaving the gate, stop and try again in 2 seconds
				std::this_thread::sleep_for(std::chrono::seconds(2));
			}
			//cout << "mutex locked" << endl;
			//std::this_thread::sleep_for(std::chrono::seconds(2));
			Node start = Node(ghost->getX(), ghost->getY());
			Node end = Node(13, 9);
			vector<Node> path = shortestPath(start, end);
			//cout << path.size() << endl;
			for (int i = path.size() - 2; i >= 0;i--) {
				ghost->move(path.at(i).x, path.at(i).y);
				std::this_thread::sleep_for(std::chrono::milliseconds(300));
			}
			ghost->inGate = false;
			
			leaveGateMutex.unlock();
		}
		if (!poweredup) {
			Node start = Node(ghost->getX(), ghost->getY());
			Node end = Node(pacman.getX(), pacman.getY());
			vector<Node> path = shortestPath(start, end);
			
			try {
				newx = path.at(path.size() - 2).x;
				newy = path.at(path.size() - 2).y;
			}
			catch (const std::out_of_range& e) { //if path.size() <1, theyre on top of each other. dont move.
				//cout << "path vector out of range error" << endl;
				newx = ghost->getX();
				newy = ghost->getY();
			}
			
			ghost->move(newx, newy);
		}
	else {
			
			if (pacman.getY() > ghost->getY()) {
				if (ghost->getY() > 0) {
					newy = ghost->getY() - 1;
					newx = ghost->getX();
					if (ghost->move(newx, newy)) {
						continue;
					}
				}
			}
			if (pacman.getX() > ghost->getX()) {
				if (ghost->getX() > 0) {
					newx = ghost->getX() - 1;
					newy = ghost->getY();
					if (ghost->move(newx, newy)) {
						continue;
					}
				}
			}
			if (pacman.getX() < ghost->getX()) {
				if (ghost->getX() < 21) {
					newx = ghost->getX() +1;
					newy = ghost->getY();
					if (ghost->move(newx, newy)) {
						continue;
					}
				}
			}

			if (pacman.getY() < ghost->getY()) {
				if (ghost->getY() < 18) {
					newx = ghost->getX();
					newy = ghost->getY() + 1;
					if (ghost->move(newx, newy)) {
						continue;
					}
				}
			}
		}
		
		
	}
}

//resets ghost to initial position
void ECE_Ghost::resetGhost() {
	if (honeydew) {
		maze[xpos][ypos] = 'H';
		honeydew = false;
	}
	else if (powerup) {
		maze[xpos][ypos]  = 'P';
		powerup = false;
	}
	else {
		maze[xpos][ypos] = 'E';
	}
	xpos = startx;
	ypos = starty;
	if (poweredup) {
		std::this_thread::sleep_for(std::chrono::seconds(5));
	}
	maze[xpos][ypos] = map_char;
	inGate = true;
	reset = false;
	glutPostRedisplay();
	std::this_thread::sleep_for(std::chrono::seconds(2));
	
}
//starts thread
void ECE_Ghost::startThread() {
	th = thread(ghostActions, this);
	std::this_thread::sleep_for(std::chrono::milliseconds(300));
}
//default constructor
ECE_Ghost::ECE_Ghost()
{
	switch (numGhosts) {
	case 3:
		red = 0.0;
		green = 1.0;
		blue = 1.0;
		xpos = 11;
		ypos = 8;
		break;
	case 1:
		red = 1.0;
		green = 0.71875;
		blue = 1.0;
		xpos = 11;
		ypos = 9;
		break;
	case 2:
		red = 1.0;
		green = 0.0;
		blue = 0.0;
		xpos = 11;
		ypos = 10;
		break;
	case 0:
		red = 1.0;
		green = 0.71875;
		blue = 0.32421875;
		xpos = 12;
		ypos = 9;
		break;
	//there shouldnt be more than 5 ghosts, make it black and not in the maze
	default:
		red = 0.0;
		green = 0.0;
		blue = 0.0;
		xpos = NULL;
		ypos = NULL;
	}
	map_char = '0' + (numGhosts+1);
	honeydew = false;
	powerup = false;
	inGate = true;
	reset = false;
	maze[xpos][ypos] = map_char;
	startx = xpos;
	starty = ypos;
	numGhosts++;
	//if (numGhosts == 1) {
	//th = thread(ghostActions, this);
	std::this_thread::sleep_for(std::chrono::milliseconds(10));
	//}
};

//move ghost to new location
bool ECE_Ghost::move(int newx, int newy) {
	mazeMutex.lock();

	if (original_maze[newx][newy] != 'W'){
		if (inGate || (maze[newx][newy] != '1' && maze[newx][newy] != '2' && maze[newx][newy] != '3' && maze[newx][newy] != '4')) {

			if (honeydew) {
				maze[xpos][ypos] = 'H';
			}
			else if (powerup) {
				maze[xpos][ypos] = 'P';
			}
			else {
				maze[xpos][ypos] = 'E';
			}

			//put ghost in new position
			if (maze[newx][newy] == 'H') {
				honeydew = true;
			}
			else {
				honeydew = false;
			}
			if (maze[newx][newy] == 'P') {
				powerup = true;
			}
			else {
				powerup = false;
			}

			if (maze[newx][newy] == 'M') {
				if (!poweredup) {
					//cant call this from not the main thread bc it breaks
					pacman.pacmandies();
				}
			}

			maze[newx][newy] = map_char;

			xpos = newx;
			ypos = newy;
			mazeMutex.unlock();
			return true;
		}
	}

	mazeMutex.unlock();
	return false;
}

//draws ghost as a cylinder with a sphere, in the color of that ghost
void ECE_Ghost::drawGhost() {
	if (poweredup) {
		glColor3f(1.0, 1.0,1.0);
	}
	else{
		glColor3f(red, green, blue);
	}
	//body
	glPushMatrix();
	glTranslatef(0.0,0.0, -4);
	//glBindTexture(GL_TEXTURE_2D, texture[0]);
	GLUquadricObj* q;
	q = gluNewQuadric();
	gluCylinder(q, 3.0, 3.0, 5.0, 30, 30);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.0, 0.0, 1);
	glutSolidSphere(3.0, 20, 20);
	glPopMatrix();
}

/*
GETTERS AND SETTERS
*/

std::thread& ECE_Ghost::getThread() {
	return th;
}

char ECE_Ghost::getMapChar() {
	return map_char;
}

void ECE_Ghost::setX(int x) {
	xpos = x;
}

void ECE_Ghost::setY(int y) {
	ypos = y;
}