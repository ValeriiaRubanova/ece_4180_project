/*
Author: Rachel Paul
Class: ECE4122
Last Date Modified: 12/1/2020
Description:
    node header file for A* algorithm nodes
*/

#pragma once
#include <vector>
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Node
{
public:
    Node(int, int);
    Node();
    vector<Node> getNeighbors(const vector < vector <Node> >&);

    int x, y;
    int parentX = NULL;
    int parentY = NULL;
    double f, g, h;
};

bool isValid(int, int);
bool isDestination(int, int, Node);
double calcHVal(int, int, Node);
void removeElement(Node, vector<Node>&);
bool hasElement(Node, const vector<Node>&);

vector<Node> aStar(Node, Node);
